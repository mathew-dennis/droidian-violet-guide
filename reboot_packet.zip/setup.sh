# Droidian Adaptation for the Xiaomi Redmi note  pro (violet)
# Flashing based on: https://github.com/droidian-releng/android-recovery-flashing-template

# Contains fixes for:
# 1. udev
# 2. mask some crashing services
# 3. wifi

# https://droidian.org

OUTFD=/proc/self/fd/$1;
VENDOR_DEVICE_PROP=`grep ro.product.vendor.device /vendor/build.prop | cut -d "=" -f 2 | awk '{print tolower($0)}'`;

# ui_print <text>
ui_print() { echo -e "ui_print $1\nui_print" > $OUTFD; }

# This package force reboots the device to recovery
ui_print " rebooting....";
sleep 5;
reboot bootloader;


exit 0;
